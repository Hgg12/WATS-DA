res_model = "re_detector/checkpoints/resnet18.pth"

guid_model =  "re_detector/checkpoints/best_mse.pth"
